using Turing
using DifferentialEquations
using Distributions
using Random
using DataFrames
using SciMLBase
using Statistics
using FlexiChains
using DynamicPPL: @varname

import StatsPlots
import PairPlots
import CairoMakie

Random.seed!(123)

# ============================================================
# 1. 定义物理方程
# ============================================================

function forced_damped_oscillator!(du, u, p, t)
    ω0, γ, ω, F0 = p

    x = u[1]
    v = u[2]

    du[1] = v
    du[2] = -2.0 * γ * v - ω0^2 * x + F0 * cos(ω * t)
end

# ============================================================
# 2. 生成带误差条的模拟实验数据
# ============================================================

true_p = [3.0, 0.2, 2.5, 2.0]     # 真实参数：ω0, γ, ω, F0
u0 = [1.5, 0.0]
tspan = (0.0, 15.0)
t_data = collect(range(0.0, 15.0, length=120))

prob_true = ODEProblem(forced_damped_oscillator!, u0, tspan, true_p)
sol_true = solve(prob_true, Tsit5(); saveat=t_data)

x_clean = [u[1] for u in sol_true.u]

# ------------------------------------------------------------
# y_error 表示每个实验点的纵向误差。
# 这里先假设所有点的 y 误差相同，均为 0.15。
# 如果真实实验每个点误差不同，就把这里替换成你的误差数组。
# ------------------------------------------------------------

y_error = fill(0.15, length(t_data))

# x_data 是实验中心值。
# 这里为了模拟实验数据，仍然用 y_error 作为标准差生成中心值的随机偏移。
x_data = x_clean .+ rand.(Normal.(0.0, y_error))

@assert length(x_data) == length(t_data)
@assert length(y_error) == length(t_data)
@assert all(y_error .> 0.0)

println(">> 已生成带误差条的实验数据，数据点数量: $(length(t_data))")

# ============================================================
# 3. 定义 Turing 模型
# ============================================================
@model function fit_forced_oscillator(t, x_obs, x_err, u0, tspan)
    ω0 ~ truncated(Normal(3.0, 0.5), 1.0, 5.0)
    γ  ~ truncated(Normal(0.2, 0.15), 0.0, 1.0)
    ω  ~ truncated(Normal(2.5, 0.5), 1.0, 5.0)
    F0 ~ truncated(Normal(2.0, 1.0), 0.5, 4.0)

    p = [ω0, γ, ω, F0]

    prob = ODEProblem(forced_damped_oscillator!, u0, tspan, p)

    sol = solve(
        prob,
        Tsit5();
        saveat=t,
        reltol=1e-6,
        abstol=1e-6,
        verbose=false
    )

    if !SciMLBase.successful_retcode(sol) || length(sol.u) != length(t)
        Turing.@addlogprob! -Inf
        return
    end

    for i in eachindex(t)
        x_obs[i] ~ Normal(sol.u[i][1], x_err[i])
    end
end
# ============================================================
# 4. 采样、后处理和绘图
# ============================================================

let
    oscillator_model = fit_forced_oscillator(t_data, x_data, y_error, u0, tspan)

    println(">> 正在启动 NUTS 采样器...")
    println(">> 采样参数：1000 次采样，4 条链，使用多线程。")
    chain = sample(
        oscillator_model,
        NUTS(0.65),
        MCMCThreads(),
        1000,
        4
    )

    # 正式分析建议用四链：
    # chain = sample(
    #     oscillator_model,
    #     NUTS(0.65),
    #     MCMCThreads(),
    #     1000,
    #     4
    # )
    
    # 多线程运行：
    # julia -t 4 sim_h.jl

    println("\n>> chain 类型：")
    println(typeof(chain))

    println("\n>> 后验统计摘要：")
    ss = FlexiChains.summarystats(chain)
    display(ss)

    # ========================================================
    # 4.1 提取后验样本
    # ========================================================

    posterior_df = DataFrame(
        ω0 = vec(Array(chain[@varname(ω0)])),
        γ  = vec(Array(chain[@varname(γ)])),
        ω  = vec(Array(chain[@varname(ω)])),
        F0 = vec(Array(chain[@varname(F0)]))
    )

    physical_df = posterior_df[:, [:ω0, :γ, :ω, :F0]]

    println("\n>> 后验均值参数：")

    p_mean = [
        mean(posterior_df.ω0),
        mean(posterior_df.γ),
        mean(posterior_df.ω),
        mean(posterior_df.F0)
    ]

    println("ω0 = $(p_mean[1])")
    println("γ  = $(p_mean[2])")
    println("ω  = $(p_mean[3])")
    println("F0 = $(p_mean[4])")

    # ========================================================
    # 4.2 轨迹图和边际分布图
    # ========================================================

    println("\n>> 正在绘制参数轨迹和边际分布图...")

    p_trace = StatsPlots.plot(chain; size=(900, 1000))
    StatsPlots.savefig(p_trace, "param_distributions.svg")

    println("- 参数轨迹与边际分布图已保存至 param_distributions.svg")

    # ========================================================
    # 4.3 参数联合分布角图
    # ========================================================

    println("\n>> 正在绘制参数联合分布角图...")

    fig_corner = PairPlots.pairplot(physical_df)
    CairoMakie.save("corner_plot.svg", fig_corner)

    println("- 参数联合分布角图已保存至 corner_plot.svg")

    # ========================================================
    # 4.4 绘制实验中心值、误差条和后验均值拟合曲线
    # ========================================================

    println("\n>> 正在绘制实验数据与拟合曲线...")

    t_fit = collect(range(tspan[1], tspan[2], length=400))

    prob_fit = ODEProblem(forced_damped_oscillator!, u0, tspan, p_mean)
    sol_fit = solve(prob_fit, Tsit5(); saveat=t_fit, reltol=1e-6, abstol=1e-6)

    if !SciMLBase.successful_retcode(sol_fit)
        error("后验均值参数对应的 ODE 求解失败。")
    end

    x_fit = [u[1] for u in sol_fit.u]

    # 真实无噪声曲线。真实实验数据时应删掉这部分。
    sol_true_dense = solve(prob_true, Tsit5(); saveat=t_fit)
    x_true_dense = [u[1] for u in sol_true_dense.u]

    p_fit = StatsPlots.scatter(
        t_data,
        x_data;
        yerror=y_error,
        label="Observed center ± y error",
        xlabel="t",
        ylabel="x(t)",
        markersize=3,
        size=(900, 500)
    )

    StatsPlots.plot!(
        p_fit,
        t_fit,
        x_fit;
        linewidth=2,
        label="Posterior mean fit"
    )

    StatsPlots.plot!(
        p_fit,
        t_fit,
        x_true_dense;
        linewidth=2,
        linestyle=:dash,
        label="True noiseless curve"
    )

    StatsPlots.savefig(p_fit, "fit_curve.svg")

    println("- 实验中心值、误差条与拟合曲线图已保存至 fit_curve.svg")

    # ========================================================
    # 4.5 后验可信带
    # ========================================================
    #
    # 这里的 95% band 是参数不确定性传播到模型曲线后的可信带。
    # 它不是实验误差条本身。
    # 实验误差条已经通过 y_error 进入似然函数。

    println("\n>> 正在绘制 95% 后验曲线带...")

    nsample_fit = min(300, nrow(posterior_df))
    idx = randperm(nrow(posterior_df))[1:nsample_fit]

    x_sims = Matrix{Float64}(undef, nsample_fit, length(t_fit))

    for (j, k) in enumerate(idx)
        p_sample = [
            posterior_df.ω0[k],
            posterior_df.γ[k],
            posterior_df.ω[k],
            posterior_df.F0[k]
        ]

        prob_sample = ODEProblem(forced_damped_oscillator!, u0, tspan, p_sample)

        sol_sample = solve(
            prob_sample,
            Tsit5();
            saveat=t_fit,
            reltol=1e-5,
            abstol=1e-5
        )

        if SciMLBase.successful_retcode(sol_sample) && length(sol_sample.u) == length(t_fit)
            x_sims[j, :] .= [u[1] for u in sol_sample.u]
        else
            x_sims[j, :] .= NaN
        end
    end
    # 就放在这里
    x_med = [
    quantile(filter(!isnan, x_sims[:, i]), 0.50)
    for i in axes(x_sims, 2)
    ]

    x_low = [
    quantile(filter(!isnan, x_sims[:, i]), 0.025)
    for i in axes(x_sims, 2)
    ]

    x_high = [
    quantile(filter(!isnan, x_sims[:, i]), 0.975)
    for i in axes(x_sims, 2)
    ]

    p_band = StatsPlots.scatter(
        t_data,
        x_data;
        yerror=y_error,
        label="Observed center ± y error",
        xlabel="t",
        ylabel="x(t)",
        markersize=3,
        size=(900, 500)
    )

    StatsPlots.plot!(
        p_band,
        t_fit,
        x_med;
        linewidth=2,
        label="Posterior median curve"
    )

    StatsPlots.plot!(
        p_band,
        t_fit,
        x_low;
        fillrange=x_high,
        fillalpha=0.20,
        linewidth=0,
        label="95% model credible band"
    )

    StatsPlots.plot!(
        p_band,
        t_fit,
        x_true_dense;
        linewidth=2,
        linestyle=:dash,
        label="True noiseless curve"
    )

    StatsPlots.savefig(p_band, "fit_curve_with_band.svg")

    println("- 带误差条和 95% 后验曲线带的拟合图已保存至 fit_curve_with_band.svg")

    println("\n>> 所有任务完成。")
end